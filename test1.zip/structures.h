#include <ios>
#include <stdexcept>
#include <string>
#include <vector>
#include <memory>
#include <iostream>


#include <SDL2/SDL.h>
#include <SDL2/SDL_surface.h>
#include <SDL2/SDL_rect.h>

#include <SDL2/SDL_image.h>

#ifndef STRUCTURES_HEADER 
#define STRUCTURES_HEADER

enum position {
	left,
	right,
	middle_bottom,
	top,
	bottom,
};


/**
 * @brief Image class that stores SDL bitmaps and metadata
 * 
 */
class Image {
	public:
		std::string url;
		
		std::shared_ptr<SDL_Surface> imageSurface;
		 

		/**
		 * @brief Construct a new Image object from scratch.
		 * Normal constructor to make a new Image. This will load the image pointed to by location, and will assign it to an SDL_Surface
		 * @param location Absolute or (preferably) relative path to image.
		 */
		Image(std::string location) : url(location), imageSurface{IMG_Load(url.c_str()), SDL_FreeSurface} {
			if (imageSurface == nullptr) {
				throw std::runtime_error("\033[1m\033[31mFatal error: Image '" + url + "' could not be loaded.\033[37m");
			}
		};

		/**
		 * @brief Construct a new Image object from an existing SDL_Surface.
		 * 
		 * @param surf Pointer to a dynamically allocated SDL_Surface
		 */
		Image(SDL_Surface* surf) : url("undefined"), imageSurface(surf) {
		};

		// Create a function overload to allow for the creation of an Image with a shared_ptr<SDL_Surface> that has a null deleter.
		// Useful for when the surface is automatically managed elsewhere, and deleting it here would cause undefined or erroneous behaviour.
		// Use only if you are completely sure that having a null deleter for the Image won't lead to memory leaks.

		/**
		 * @brief Construct a new Image object from an existing SDL_Surface, without managing the pointer.
		 * 
		 * @param surf 
		 * @param jankyEnabler May be any bool-compatible value, it will just be ignored.
		 */
		Image(SDL_Surface* surf, bool jankyEnabler) : url("undefined"), imageSurface(surf, [](SDL_Surface*){}) {
		};

		Image() = default;

		SDL_Surface* getSurface() {
			return imageSurface.get();
		};

};

class Character {
	public:
		std::string name;
		Image charImage;
	public:
		Character(std::string characterName, std::string imageURL) : name{characterName}, charImage{imageURL} {
		}

		Character() = default;

};

class Frame {
	public:
		std::string textDialogue;
		Character& storyCharacter;
	public:
		Frame(std::string dialogue, Character& character) : textDialogue{dialogue}, storyCharacter{character} {
		}

		Frame() = delete;
};

class Chapter {
	public:
		std::string chapterName;
		std::vector<Character> storyCharacters;
		std::vector<Frame> storyFrames;
	public:
		Chapter(std::string name, std::vector<Character> characters, std::vector<Frame> frames) : chapterName{name}, storyCharacters{characters}, storyFrames{frames} {
		}

		Chapter() = default;
};


#endif